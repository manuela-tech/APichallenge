# 🗂️ Challenge ForoHub
La API estará disponible en http://localhost:8080

API REST construida con **Spring Boot 3**, **Spring Security + JWT** y **MySQL** **como parte del Challenge Foro Hub **

---

## ✅ Funcionalidades

| Método | Endpoint         | Descripción                        | Auth |
|--------|------------------|------------------------------------|------|
| POST   | `/login`         | Autenticación y obtención de token | ❌    |
| POST   | `/usuarios`      | Registro de nuevo usuario          | ❌    |
| GET    | `/usuarios`      | Listar todos los usuarios          | ✅    |
| GET    | `/usuarios/{id}` | Obtener usuario por ID             | ✅    |
| DELETE | `/usuarios/{id}` | Eliminar usuario                   | ✅    |
| POST   | `/topicos`       | Crear nuevo tópico                 | ✅    |
| GET    | `/topicos`       | Listar tópicos (paginado)          | ✅    |
| GET    | `/topicos/{id}`  | Obtener tópico por ID              | ✅    |
| PUT    | `/topicos/{id}`  | Actualizar tópico                  | ✅    |
| DELETE | `/topicos/{id}`  | Eliminar tópico (lógico)           | ✅    |

---

## 🛠️ Tecnologías
- MySQL 8
- Java 17
- Spring Boot 4.0.3
- Spring Security + JWT (Auth0 java-jwt)
- Spring Data JPA + Hibernate
- Flyway (migraciones de BD)
- Lombok
- auth0 4.4.0
- Ejecutar con Maven 4.0.0

---

## 🚀 Configuración y ejecución

### Pre-requisitos (Software que utilice)
- IntelliJ IDEA 2025.3.1
- Java 17+
- MySQL corriendo en `localhost:3306`
- Insomnia 12.4.0

### Variables de entorno (opcionales)

| Variable      | Valor por defecto                    |
|---------------|--------------------------------------|
| `DB_USER`     | `root`                               |
| `DB_PASSWORD` | `root`                               |
| `JWT_SECRET`  | `forohub-secret-key-alura-2024-...`  |

---

## 🔐 Autenticación

### 1. Registro

```http
POST /usuarios
Content-Type: application/json

{
  "nombre": "Tu Nombre",
  "correoElectronico": "tu@email.com",
  "contrasena": "123456"
}
```

### 2. Login

```http
POST /login
Content-Type: application/json

{
  "correoElectronico": "admin@forohub.com",
  "contrasena": "123456"
}
```

Respuesta:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### 3. Usar el token

Agrega el header en todas las peticiones protegidas:

```
Authorization: Bearer <token>
```

---

## 📝 Ejemplos de uso — Tópicos

### Crear tópico

```http
POST /topicos
Authorization: Bearer <token>
Content-Type: application/json

{
  "titulo": "¿Cómo usar Spring Security?",
  "mensaje": "Tengo dudas sobre la configuración de Spring Security con JWT.",
  "autorId": 1,
  "cursoId": 1
}
```

### Listar tópicos

```http
GET /topicos?page=0&size=10&sort=fechaCreacion,asc
Authorization: Bearer <token>
```

### Actualizar tópico

```http
PUT /topicos/1
Authorization: Bearer <token>
Content-Type: application/json

{
  "titulo": "Nuevo título actualizado",
  "status": "CERRADO"
}
```

### Eliminar tópico (borrado lógico)

```http
DELETE /topicos/1
Authorization: Bearer <token>
```

---

## Usuario de prueba: 

`"correoElectronico": "admin@forohub.com"`
`contrasena": "123456"`

---

## 👤 Autor

 Desarrollado por Erick Hernandez, como parte del Cuarto y ultimo Challenge de Alura.
