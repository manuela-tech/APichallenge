package com.alura.Challenge.Foro.Hub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeForoHubApplicationTests {

	@Test
	void contextLoads() {
	}

}
