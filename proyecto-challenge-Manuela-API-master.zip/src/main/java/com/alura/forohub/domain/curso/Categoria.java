package com.alura.forohub.domain.curso;

public enum Categoria {
    PROGRAMACION,
    DEVOPS,
    FRONT_END,
    BACK_END,
    BASE_DE_DATOS
}
