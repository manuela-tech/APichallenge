package com.alura.forohub.domain.topico;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DatosRegistroTopico(
        @NotBlank(message = "El título es obligatorio")
        String titulo,

        @NotBlank(message = "El mensaje es obligatorio")
        String mensaje,

        @NotNull(message = "El id del autor es obligatorio")
        Long idAutor,

        @NotBlank(message = "El nombre del curso es obligatorio")
        String nombreCurso
) {
}
